export const environment: any = { // PRODUCTION ENVIRONMENT VARIABLES 
  production: true,
  baseUrl: 'http://34.228.54.231',
  apiUrl: 'http://54.81.138.22:5008',
  emailSendTo: [
    { email: 'documentuploads@millenniapay.com' }
  ],
  linkExpiredAfter: 0
};


